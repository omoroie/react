function NotFound() {
    return <h2>페이지를 찾을 수 없습니다.</h2>
  }
  
  export default NotFound
  